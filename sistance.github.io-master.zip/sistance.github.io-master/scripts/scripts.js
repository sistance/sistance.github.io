// $ = jQuery
$(document).on("ready",function(){
	
});


$(window).on("load",function(){
	
});